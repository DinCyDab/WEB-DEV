<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="src/css/styles.css">
    </head>
    <body>
        <div class="container">
            <div class="grid">
                <div class="navigation-tab">
                    <?php 
                        include "src/html/navigation-bar.html";
                    ?>
                </div>
                <div class="header">
                    <?php 
                        include "src/html/header.html";
                    ?>
                </div>
                <div class="content">
                    <?php 
                        include "src/html/dashboard-content.html";
                    ?>
                </div>
            </div>
        </div>
    </body>
</html>